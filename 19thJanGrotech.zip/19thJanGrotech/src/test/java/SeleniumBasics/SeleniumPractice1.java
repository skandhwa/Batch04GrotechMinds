package SeleniumBasics;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class SeleniumPractice1 {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
	String Title=	driver.getTitle();
	System.out.println(Title);
	driver.manage().window().maximize();
	
	
	String CurrentURL=driver.getCurrentUrl();
	System.out.println(CurrentURL);
	
	Thread.sleep(3000);
	
//	String PageSource=driver.getPageSource();
//	System.out.println(PageSource);
	
	driver.close();
	
	
	
	
	
		
		
		
//		
//		WebDriver driver1=new FirefoxDriver();
//		driver1.get("https://www.flipkart.com");
//		
//		WebDriver driver2=new EdgeDriver();
//		driver2.get("https://www.amazon.co.in");
		
		

	}

}
