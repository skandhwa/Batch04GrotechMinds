package TestNgNewScratch.NewTestNgScratch;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Pagefactory.HomePage;
import Utilities.GetDataFromExcel;
import Utilities.ReadDataFromProperty;

public class TestCaseExecution {
	
	ReadDataFromProperty obj1=new ReadDataFromProperty();
	//public static WebDriver driver=new ChromeDriver();
	public static WebDriver driver;
	
	GetDataFromExcel obj2=new GetDataFromExcel();
	HomePage obj3=new HomePage();
	
	
	@BeforeTest
	public void openBrowser() throws IOException
	{
		String Browsername=obj1.ReadDataProperty().getProperty("browser");
		if(Browsername.equalsIgnoreCase("chrome"))
		{
			driver=new ChromeDriver();
			driver.get(obj2.getURL());
			driver.manage().window().maximize();
		}
		
		if(Browsername.equalsIgnoreCase("firefox"))
		{
			driver=new FirefoxDriver();
			driver.get(obj2.getURL());
			driver.manage().window().maximize();
		}
		
		if(Browsername.equalsIgnoreCase("edge"))
		{
			driver=new EdgeDriver();
			driver.get(obj2.getURL());
			driver.manage().window().maximize();
		}
	}
	
	@Test
	public void executetest() throws IOException
	{
		String firstname=obj1.ReadDataProperty().getProperty("firstname");
		String lastname=obj1.ReadDataProperty().getProperty("lastname");
		driver.findElement(By.xpath(obj3.getfirstname())).sendKeys(firstname);
		driver.findElement(By.xpath(obj3.getlastname())).sendKeys(lastname);
		
		
		
		
	}
	
	
	
	
	
	

}
