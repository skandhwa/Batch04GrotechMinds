package BasicofJava;

public class MethodDeclaration2 {
	
	void display()
	{
		System.out.println("Hello How are you");
	}
	
	void message()
	{
		System.out.println("I am message method");
	}
	
	
	public static void main(String[] args) {
		
		MethodDeclaration2 obj=new MethodDeclaration2();
		obj.display();
		obj.message();
		

	}

}
