package BasicofJava;

class D
{
	int add(int a,int b,int c)
	{
		return a+b+c;
	}
	
	int sub(int d,int e)
	{
		return d-e;
	}
}
public class MethodDeclaration5 {
	
	int multiply(int h,int j)
	{
		return h*j;
	}
	

	public static void main(String[] args) {
		
		D obj=new D();
	System.out.println(obj.add(12, 34, 56));	
	System.out.println(	obj.sub(45, 11));
	
	MethodDeclaration5 obj1=new MethodDeclaration5();
	System.out.println(obj1.multiply(34, 5));
		
		
		

	}

}
