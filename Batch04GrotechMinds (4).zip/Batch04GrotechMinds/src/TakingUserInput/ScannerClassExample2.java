package TakingUserInput;

import java.util.Scanner;

public class ScannerClassExample2 {

	public static void main(String[] args) {
	
		
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter First Number");
		
		float x=sc.nextFloat();
		
         System.out.println("Enter Second Number");
		
		float y=sc.nextFloat();
		
		float z=x+y;
		System.out.println("The Sum of X and Y is  "+z);
		
		
		

	}

}
