package TakingUserInput;

import java.util.Scanner;

public class SwitchExample1 {

	public static void main(String[] args) {
		
		int day;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter any number between 1-7");
		
		day=sc.nextInt();
		
		
		
		switch(day)
		{
		
		case 1:
			System.out.println("Sunday");
			 
			  
		case 2:
			System.out.println("Monday");
			
			  
		    
		case 3:
			System.out.println("Tuesday");
			 
			  
		    
		case 4:
			System.out.println("Wednesday");
			  
			  
		    
		 default:
			 System.out.println("Not a valid input");
			 
		
		}
		
		}
	}


