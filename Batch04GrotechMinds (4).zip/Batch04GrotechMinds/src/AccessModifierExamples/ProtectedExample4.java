package AccessModifierExamples;

public class ProtectedExample4 {
	
	protected void display()
	{
		System.out.println("I am new Display method of Protected");
	}
	

	public static void main(String[] args) {
		
		ProtectedExample4 obj=new ProtectedExample4();
		obj.display();
		
		

	}

}
