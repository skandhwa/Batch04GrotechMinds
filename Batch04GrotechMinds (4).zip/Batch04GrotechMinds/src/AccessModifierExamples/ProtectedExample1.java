package AccessModifierExamples;



public class ProtectedExample1 {
	public static void main(String[] args) {
		
		
		Test6 obj=new Test6();
		obj.display();
		
		

	}

}
