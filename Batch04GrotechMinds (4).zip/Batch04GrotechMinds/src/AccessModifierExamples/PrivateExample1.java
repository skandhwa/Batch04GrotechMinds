package AccessModifierExamples;

class Display1
{
	 private int x=20;
	
	void test1()
	{
		int y=x+30;
		System.out.println(y);
	}
	
	private void msg()
	{
		System.out.println("Hello");
	}
	
}


class Display2 extends Display1
{
	void message1()
	{
		System.out.println(super.x);
	}
	
}





public class PrivateExample1 {
	
public static void main(String[] args) {
	
	Display1 obj=new Display1();
	obj.test1();
	obj.msg();
	
		
		
		
		
	
		

	}

}
