package EncapsuationExamples;

public class EncapsulationExample2 {

	public static void main(String[] args) {
		
		EncapsulationExample1 obj=new EncapsulationExample1();
		obj.setName("Mahesh");
		
		System.out.println(obj.getName());
		
		

	}

}
