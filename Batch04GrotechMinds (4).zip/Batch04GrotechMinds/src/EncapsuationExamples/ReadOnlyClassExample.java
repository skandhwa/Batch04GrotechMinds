package EncapsuationExamples;

public class ReadOnlyClassExample {

	
		
		private String college="IIT";

		public String getCollege() {
			return college;
		}
		
		

	

}
