package EncapsuationExamples;

public class EncapsulationExample3 {

	public static void main(String[] args) {
		
		ReadOnlyClassExample obj=new ReadOnlyClassExample();
	System.out.println(obj.getCollege());	
		

	}

}
