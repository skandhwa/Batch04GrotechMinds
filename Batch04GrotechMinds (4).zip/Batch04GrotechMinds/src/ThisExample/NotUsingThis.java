package ThisExample;

class Employee5
{
	String empname;
	int empid;
	int salary;
	
	Employee5(String empname,int empid,int salary)
	{
		this.empname=empname;
		this.empid=empid;
		this.salary=salary;
	}
	
	void display()
	{
		System.out.println(empname+" "+empid+" "+salary);
	}
	
	
}
public class NotUsingThis {

	public static void main(String[] args) {
		
		Employee5 obj=new Employee5("Mohit",345,6000);
		obj.display();
		
		Employee5 obj1=new Employee5("Rohit",145,9000);
		obj1.display();

	}

}
