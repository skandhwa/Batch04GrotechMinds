package PolyMorphismEx;

class Bank
{
	int getROI()
	{
		return 8;
	}
	
	void display()
	{
		System.out.println("Hello ");
	}
}

class Axis extends Bank
{
	int getROI()
	{
		return 10;
	}
	
}

class SBI extends Bank
{
	int getROI()
	{
		return 12;
	}
	
}

class HDFC extends Bank
{
	int getROI()
	{
		return 14;
	}
	
}

public class MethodOverdidingEx2 {

	public static void main(String[] args) {
		
		Bank obj=new Bank();
	System.out.println(obj.getROI());	
		
	HDFC obj1=new HDFC();
	System.out.println(obj1.getROI());	
	obj1.display();
	

	}

}
