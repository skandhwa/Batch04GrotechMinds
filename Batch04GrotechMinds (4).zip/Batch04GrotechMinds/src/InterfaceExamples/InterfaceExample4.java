package InterfaceExamples;

interface Diagram8
{
	void print();
	
}

interface Show
{
	void test();
}

interface Area
{
	void volume();
}


class Picture implements Diagram8,Show,Area
{
	public void print()
	{
		System.out.println("i am print method");
	}
	
	public void test()
	{
		System.out.println("i am test method");
	}
	
	public void volume()
	{
		System.out.println("I am volume method");
	}
}

public class InterfaceExample4 {

	public static void main(String[] args) {
	
		Diagram8 ref=new Picture();
		ref.print();
		
		Show ref1=new Picture();
		ref1.test();
		
		Area ref2=new Picture();
		ref2.volume();
		
		
		

	}

}
