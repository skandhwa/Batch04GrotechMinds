package InterfaceExamples;

interface Show3
{
	void area();
	void volume();
	
}

interface Picture3 extends Show3
{
	void display();
}

class Diagram4 implements Picture3 
{
	public void area()
	{
		System.out.println("I am area method");
	}
	
	public void volume()
	{
		System.out.println("I am volume method");
	}
	
	public void display()
	{
		System.out.println("I am display method");
	}
	
}

public class InterfaceExample5 {

	public static void main(String[] args) {
		
		Picture3 ref1=new Diagram4();
		ref1.volume();
		ref1.display();
		ref1.area();
		

	}

}
