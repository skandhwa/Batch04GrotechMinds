package InterfaceExamples;



interface Printable
{
	 int x=10;
	 void display();
}


class A9 implements Printable
{
	
	public void display()
	{
		System.out.println("hello");
	}
}

public class InterfaceExample1 {

	public static void main(String[] args) {
		
		Printable ref=new A9();
		ref.display();
		
		
		
		

	}

}
