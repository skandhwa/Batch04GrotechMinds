package FinalExamples;


	
	class Car4
	{
		final void speed()
		{
			System.out.println("I am running wih 100 kmph");
		}
	}
	
	
	class Bike9 extends Car4
	{
		void speed()
		{
			System.out.println("I am running wih 200 kmph");
		}
		
		
		
	}
	

	public class finalMethodExample {
	
	public static void main(String[] args) {
		
		Bike9 obj=new Bike9();
		obj.speed();
		

	}

}
