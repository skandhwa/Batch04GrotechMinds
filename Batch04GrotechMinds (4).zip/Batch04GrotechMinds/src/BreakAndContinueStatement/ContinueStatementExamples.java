package BreakAndContinueStatement;

public class ContinueStatementExamples {

	public static void main(String[] args) {
		
		
		for(int i=1;i<=10;i++)//i=1,1<=10,2<=10,3<=10.,5//6<=10
		{
			if(i==5)//1==5//2==5//3==5//5==5//6==5
			{
				continue;
			}
			
			System.out.println(i);//1//2//3//4//6
		}
		
	
		

	}

}
