package BreakAndContinueStatement;

public class BreakStatementDoWhile {

	public static void main(String[] args) {
		
		int i=1;
		do
		{
			if(i==5)//1==5//2==5//3==5//4==5///5==5
			{
				i++;
				break;
			}
			
			System.out.println(i);//1//2//3//4
			i++;
			
		}
		
		while(i<=10);//2<=10//3<=10
		
		

	}

}
