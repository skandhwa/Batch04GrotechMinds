package AbstractionEx;

abstract class Shape
{
	abstract void draw();
	void display()
	{
		System.out.println("Hello");
	}
	
	void message()
	{
		System.out.println("Hi");
	}
	
	abstract void area();
	
}


class Rectangle extends Shape
{
	void draw()
	{
		System.out.println("I am drawing rectangle");
	}
	void area()
	{
		System.out.println("I am area method of rectangle");
	}
}

class Square extends Shape
{
	void draw()
	{
		System.out.println("I am drawing square");
	}
	void area()
	{
		System.out.println("I am area method of square");
	}
	
}

public class AbstractClassExample2 {

	public static void main(String[] args) {
		
		Shape ref=new Rectangle();
		ref.area();
		ref.display();
		ref.draw();
		
		Shape ref1=new Square();
		ref1.area();
		ref1.draw();
		
		

	}

}
