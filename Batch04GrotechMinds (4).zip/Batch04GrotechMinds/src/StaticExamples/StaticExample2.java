package StaticExamples;

class Student9
{
	int rollno;
	String name;
	static String collegename="NIT";


static void change()
{
	collegename="IIT";
}


}

public class StaticExample2 {

	public static void main(String[] args) {
		
	}

}
