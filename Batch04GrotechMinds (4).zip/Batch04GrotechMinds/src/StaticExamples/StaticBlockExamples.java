package StaticExamples;

public class StaticBlockExamples {
	
	static 
	{
		System.out.println("I am static block");
	}
	
	void display()
	{
		System.out.println("Hello iam display method");
	}
	
	
	

	public static void main(String[] args) {
		
		System.out.println("Hello saurabh");
		
		StaticBlockExamples obj=new StaticBlockExamples();
		obj.display();
		
		

	}

}
