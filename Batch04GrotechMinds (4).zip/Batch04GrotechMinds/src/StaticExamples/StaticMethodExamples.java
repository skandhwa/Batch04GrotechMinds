package StaticExamples;


class TV
{
	 static void channel()
	{
		System.out.println("A tv has many channels ");
	}
	 
	 static void display()
	 {
		  String name="Pnasonic";
	 }
}



public class StaticMethodExamples {

	public static void main(String[] args) {
		
		TV.channel();
		

	}

}
