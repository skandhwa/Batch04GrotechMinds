package StaticExamples;

public class StaticMainMethodEx {

	public static void main(String[] args) {
		
		System.out.println("Hello");
		
		

	}

}
