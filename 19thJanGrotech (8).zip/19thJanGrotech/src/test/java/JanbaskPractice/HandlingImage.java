package JanbaskPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingImage {

	public static void main(String[] args) {
		
		
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.amazon.in/");
		driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.xpath("//img[@alt='New looks for the new season']"));
	String str=	ele.getAttribute("src");
	System.out.println(str);
	
WebElement ele1=	driver.findElement(By.xpath("//img[@alt='Soft toys']"));

boolean flag=ele1.isDisplayed();
System.out.println(flag);


	if(flag==true)
	{
		ele1.click();
	}
	
	
	//ele.click();

	}

}
