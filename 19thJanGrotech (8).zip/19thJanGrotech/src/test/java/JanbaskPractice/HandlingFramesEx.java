package JanbaskPractice;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class HandlingFramesEx {

	public static void main(String[] args) {
		WebDriver driver=new FirefoxDriver();
		driver.get("https://demo.automationtesting.in/Frames.html");
		
		driver.manage().window().maximize();
		
  List<WebElement> li=		driver.findElements(By.tagName("iframe"));
int x=  li.size();
System.out.println("The total number of frames are " +x);
  
		
		
		driver.switchTo().frame("SingleFrame");
		driver.findElement(By.xpath("(//input[@type='text'])[1]")).sendKeys("Saurabh");
		driver.switchTo().defaultContent();
		

	}

}
