package JanbaskPractice;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingWebTable {

	public static void main(String[] args) {
		
		
		WebDriver driver=new ChromeDriver();
		driver.get("file:///C:/Users/saura/Downloads/WebTable.html");
		driver.manage().window().maximize();
List<WebElement> li=		driver.findElements(By.tagName("td"));
int x=li.size();
System.out.println("The total comumns are "+x);

List<WebElement> li2=		driver.findElements(By.tagName("tr"));
int y=li2.size();
System.out.println("The total rows are "+y);

	}

}
