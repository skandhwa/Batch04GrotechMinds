package JanbaskPractice;

import java.util.Scanner;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class CrossBrowserTestingExample {

	public static void main(String[] args) {
		
		WebDriver driver;
		System.out.println("Enter the type of browser you want to test");
		Scanner sc=new Scanner(System.in);
		String browser=sc.nextLine();
		
		if(browser.equalsIgnoreCase("chrome"))
		{
			driver=new ChromeDriver();
			
		}
		else if(browser.equalsIgnoreCase("firefox"))
		{
			driver=new FirefoxDriver();
			
		}
		
		else
		{
			driver=new EdgeDriver();
			
		}
		
		driver.get("https://www.facebook.com");
	String title=	driver.getTitle();
	System.out.println(title);
	
	
	if(title.contains("Facebook"))
	{
		System.out.println("Test Case pass");
	}
	else
	{
		System.out.println("Test Case failed");
	}
		
		
		
		
		}
		

	}


