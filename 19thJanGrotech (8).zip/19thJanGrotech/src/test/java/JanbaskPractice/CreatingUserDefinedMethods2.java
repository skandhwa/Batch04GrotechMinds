package JanbaskPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class CreatingUserDefinedMethods2 {
	
	WebDriver driver=new ChromeDriver();
	public void workWithGoogle()
	{
		driver.get("https://www.google.com");
	}
	
	public void workWithAmazon()
	{
		driver.get("https://www.amazon.com");
	}
	public void workWithFlipkart()
	{
		driver.get("https://www.flipkart.com");
	}
	
	public void getTitle()
	{
		String Title=driver.getTitle();
		System.out.println(Title);
	}
	
	public void getCurrentUrl()
	{
		String CUrl=driver.getTitle();
		System.out.println(CUrl);
	}
	
	public void closeBrowser()
	{
		driver.close();
	}
	
	
	public static void main(String[] args) throws InterruptedException {
		
		CreatingUserDefinedMethods2 obj=new CreatingUserDefinedMethods2();
		CreatingUserDefinedMethods2 obj1=new CreatingUserDefinedMethods2();
		CreatingUserDefinedMethods2 obj2=new CreatingUserDefinedMethods2();
		
		obj.workWithGoogle();
		obj.getTitle();
		obj.getCurrentUrl();
		Thread.sleep(3000);
		obj.closeBrowser();
		
		obj1.workWithAmazon();
		obj1.getTitle();
		obj1.getCurrentUrl();
		Thread.sleep(3000);
		obj1.closeBrowser();
		
		obj2.workWithFlipkart();
		obj2.getTitle();
		obj2.getCurrentUrl();
		Thread.sleep(3000);
		obj2.closeBrowser();
		
		
	}

}
