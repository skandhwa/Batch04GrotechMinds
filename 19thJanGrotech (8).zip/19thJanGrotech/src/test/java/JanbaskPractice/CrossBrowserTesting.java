package JanbaskPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class CrossBrowserTesting {

	public static void main(String[] args) {
		
		WebDriver driver1=new ChromeDriver();
		WebDriver driver2=new FirefoxDriver();
		WebDriver driver3=new EdgeDriver();
		
		driver1.get("https://www.google.com");
	String title=	driver1.getTitle();
	System.out.println("Testing in chrome browser for title "+title);
	
	driver2.get("https://www.facebook.com");
	String title1=	driver2.getTitle();
	System.out.println("Testing in Firefox browser for title "+title1);
	
	driver3.get("https://www.flipkart.com");
	String title2=	driver3.getTitle();
	System.out.println("Testing in Edge browser for title "+title2);
	
	if(title.equals(title1) && title.equals(title2) )
	{
		System.out.println("Test Case Pass");
	}
	else
	{
		System.out.println("Test Case Failed");
	}
	
		
		

	}

}
