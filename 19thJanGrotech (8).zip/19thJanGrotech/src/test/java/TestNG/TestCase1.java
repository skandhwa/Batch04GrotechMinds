package TestNG;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;



public class TestCase1 {

	@Test(invocationCount=3)
	public void GoogleLogin() throws InterruptedException
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
		driver.manage().window().maximize();
	String Title=	driver.getTitle();
	
	System.out.println(Title);
	
	Assert.assertEquals(Title,"Google123" );
	String Current_URL=driver.getCurrentUrl();
	System.out.println(Current_URL);
	
		
	}
	
	


}
