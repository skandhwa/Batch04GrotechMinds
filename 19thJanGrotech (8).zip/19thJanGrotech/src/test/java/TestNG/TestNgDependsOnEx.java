package TestNG;

import org.testng.annotations.Test;

public class TestNgDependsOnEx {
	
	@Test
	public void login()
	{
		System.out.println("This is login function");
		
	}
	
	@Test(dependsOnMethods={"login"})
	public void Searchproduct()
	{
		System.out.println("This is Searchproduct function");
	}
	
	@Test(dependsOnMethods={"Searchproduct"})
	public void AddtoCart()
	{
		System.out.println("This is AddtoCart function");
		int x=9/0;
		System.out.println(x);
	}
	
	
	@Test(dependsOnMethods={"AddtoCart"})
	public void PaymentGateway()
	{
		System.out.println("This is PaymentGateway function");
	}
	
	@Test
	public void independent()
	{
		System.out.println("I am alone");
	}
	

}
