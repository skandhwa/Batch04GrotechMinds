package SeleniumBasics;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class GetAllOptionsFromDropDown {

	public static void main(String[] args) {
		
		
		 WebDriver driver=new ChromeDriver();
			driver.get("https://demo.automationtesting.in/Register.html");
			driver.manage().window().maximize();
	WebElement ele=		driver.findElement(By.xpath("//select[@id='Skills']"));
			Select oselect=new Select(ele);
	List<WebElement> li=		oselect.getOptions();
	int x=li.size();
	System.out.println(x);
	
	for(WebElement y:li)
	{
		System.out.println(y.getText());
	}
			

	}

}
