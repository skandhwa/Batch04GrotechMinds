package SeleniumBasics;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class FindElementvsFindElements {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
		try
		{
		
		driver.findElement(By.xpath("//textarea[@class='gLFyf']")).sendKeys("Selenium");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//textarea[@class='gLFyf']")).clear();
		}
		
		catch(NoSuchElementException e)
		{
			System.out.println("Exception caught "+e);
		}
		
	List<WebElement> li=	driver.findElements(By.tagName("aytetre"));
	int x=li.size();
	System.out.println("The total links present are "+x);
	
		

	}

}
