package SeleniumBasics;


interface WD
{
	void display();
}

class RWD 
{
	void test()
	{
		System.out.println("I am test method");
	}
}


class CD extends RWD implements WD
{
	
	public void display()
	{
		System.out.println("I implemented that");
	}
	
}



public class InterfaceExplaination {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
