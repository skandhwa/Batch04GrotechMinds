package SeleniumBasics;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingDynamicWebTableFirstWay {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("C:\\Users\\saura\\Downloads\\WebTable.html");
		driver.manage().window().maximize();
		
	List <WebElement> li=	driver.findElements(By.tagName("tr"));
	int rowsize=li.size();
	System.out.println("The total number of rows are "+rowsize);
	
	String before_xpath= "//table/tbody/tr[";
	String after_xpath= "]/td[2]";
	
	for(int i=2;i<=rowsize;i++)///i=2,2<=6,//i=3,3<=6//i=4,4<=6//i=5,5<=6//6
	{
	 String Name=   driver.findElement(By.xpath(before_xpath+i+after_xpath)).getText()	;///
	 //	System.out.println(Name);
	 if(Name.equalsIgnoreCase("Ammy"))
	 {
		 
		 driver.findElement(By.xpath("//table/tbody/tr[ " +   i   + " ]/td[1]/input")).click();
		
		 
	 }
	 
	 
	}
	
	
	
	
	
	
	
	
	
		
		

	}

}
