package SeleniumBasics;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingFrames {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Frames.html");
		//driver.switchTo().frame("singleframe");
		
	List<WebElement> li=	driver.findElements(By.tagName("iframe"));
	int x=li.size();
	System.out.println("The total number of frames are "+x);
	
	for(WebElement y:li)
	{
		System.out.println(y.getText());
	}
	
	
	
	
		
		//driver.switchTo().frame("SingleFrame");
		
		
		
		
		
		//driver.findElement(By.xpath("(//input[@type='text'])[1]")).sendKeys("Saurabh");
		
		

	}

}
