package ConstrcuctorExamples;

class Animal
{
	
	Animal()
	{
		System.out.println("Animal is created");
	}
	
	
}

public class ConstructorExample1 {

	public static void main(String[] args) {
		
		
		Animal obj=new Animal();
		
		
		
		

	}

}
