package LoopinginJava;

public class MaximumBwThreeNumbers {

	public static void main(String[] args) {
		
		int a=20;
		int b=30;
		int c=100;
		int d=200;
		
		
		if(a>b && a>c && a>d)
		{
			System.out.println("A is maximum");
		}
		
		else if(b>a && b>c && b>d)
		{
			System.out.println("B is maximum");
		}
		
		else if(c>a && c>b && c>d)
		{
			System.out.println("C is maximum");
		}
		
		else
		{
			System.out.println("D is maximum");
		}
		

	}

}
