package LoopinginJava;

public class NestedIfLoop {

	public static void main(String[] args) {
	
		
		int age=21;
		
		if(age<60)//21<60
		
			if(age>18)//21>18
			
				
				if(age>22 || age<50)//21>22 && 21<50
				
					System.out.println("you have come to polling booth for casting vote");
				
				
				
		
		
		
		System.out.println("You cannot vote");

	}
	
	
	

}
