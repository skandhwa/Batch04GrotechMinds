package LoopinginJava;

public class dowhileloopExamples {

	public static void main(String[] args) {
		
		int i=1;
		do
		{
			System.out.println(i);//1//2
			i++;//1++
		}
		
		while(i<5);///1<5//2<5
		

	}

}
