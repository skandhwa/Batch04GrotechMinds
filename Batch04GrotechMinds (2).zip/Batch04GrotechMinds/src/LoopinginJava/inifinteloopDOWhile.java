package LoopinginJava;

public class inifinteloopDOWhile {

	public static void main(String[] args) {
		
		do
		{
			System.out.println("This is an infinite loop");
		}
		
		while(true);
		
		

	}

}
