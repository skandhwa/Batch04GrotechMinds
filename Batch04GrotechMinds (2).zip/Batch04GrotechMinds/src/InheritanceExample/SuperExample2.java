package InheritanceExample;

class Bird3
{
	void eat()
	{
		System.out.println("I am message");
	}
}



class Bird2 extends Bird3
{
	void eat()
	{
		System.out.println("Birds eat");
	}
}

class Parrot2 extends Bird2{
	
	void drink()
	{
		System.out.println("Parrot drinks water");
	}
	void eat()
	{
		System.out.println("parrots can eat");
	}
	
	void display()
	{
		drink();
		eat();
		super.eat();
	}
	
}
	public class SuperExample2 {

	public static void main(String[] args) {
		
		Parrot2 obj=new Parrot2();
		obj.display();
		obj.eat();
		
		
		

	}

}
