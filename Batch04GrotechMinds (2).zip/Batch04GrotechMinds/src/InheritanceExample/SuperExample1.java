package InheritanceExample;

class Animal6
{
	String colour="blue";
}

class cat extends Animal6
{
	String colour="white";
	void display()
	{
		System.out.println(colour);
		System.out.println(super.colour);
	}
	
	
}
public class SuperExample1 {

	public static void main(String[] args) {
		
		cat obj=new cat();
		obj.display();
		
	}

}
