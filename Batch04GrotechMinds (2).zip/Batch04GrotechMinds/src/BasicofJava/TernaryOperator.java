package BasicofJava;

public class TernaryOperator {

	public static void main(String[] args) {
		
		int a=20;
		int b=100;
		int c=300;
		
//		int max= a>b ? a:b;  //20>10
//		
//		System.out.println(max);
		
		int max= (a>b) ? (a>c ? a:c) : (b>c ?b:c);
		
		///  20>100  (100>300 ?100:300)
		
		System.out.println(max);
		
		
		int x=3;
		 x+=5;//x=x+5;//3+5
		 System.out.println(x);
		 
		 int y=30;
		 y%=4;
		 System.out.println(y);
		
		
		
		
		

	}

}
