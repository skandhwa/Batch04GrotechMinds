package BasicofJava;

public class JavaVariables {
	
	int g=20;
	
	void display()
	{
		System.out.println("Hello");
		int x=10;
		int h=x+g;
	}
	
	void message()
	{
		System.out.println("I am message method");
		int y=20;
		int j=y+g;
	}
	
	

	public static void main(String[] args) 
	{
		
		
		
		

	}

}
