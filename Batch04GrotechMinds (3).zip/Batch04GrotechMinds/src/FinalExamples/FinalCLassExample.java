package FinalExamples;

final class Car10
{
	void run()
	{
		System.out.println("I am running");
	}
}

class Bike10 extends Car10
{
	void display()
	{
		System.out.println("I am display method");
	}
}

public class FinalCLassExample {

	public static void main(String[] args) {
		Bike10 obj=new Bike10();
		obj.run();
		obj.display();

	}

}
