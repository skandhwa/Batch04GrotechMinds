package FinalExamples;


class Car3
{
	static final int speed=100;
	void run()
	{
		speed=200;
		System.out.println(speed);
	}
}

public class FinalVariableExample {

	public static void main(String[] args) {
		
		Car3 obj=new Car3();
		obj.run();
		
		

	}

}
