package ConstrcuctorExamples;


class Student
{
	
	int id;
	float avgmarks;
	
	void message()
	{
		System.out.println(id+"  "+avgmarks);
	}
}

public class ConstructorExample2 {

	public static void main(String[] args) 
	
	{
		
		Student obj=new Student();
		obj.message();
		
		
		
		

	}

}
