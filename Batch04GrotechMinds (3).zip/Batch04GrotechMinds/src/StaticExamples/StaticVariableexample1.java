package StaticExamples;

class Employee
{
	int empid;
	String name;
	static String companyname="TCS";
	
	
	Employee(int e,String n)
	{
		empid=e;
		name=n;
		
	}
	static void change()
	{
		companyname="Infosys";
	}
	
	
	void display()
	{
		
		System.out.println(empid +" "+name+" "+companyname);
	}
	
}
public class StaticVariableexample1 {

	public static void main(String[] args) {
		
		Employee.change();
		
		Employee obj=new Employee(1234,"Vineet");
		Employee obj1=new Employee(2234,"Manmit");
		Employee obj2=new Employee(3234,"Rohit");
		obj.display();
		obj1.display();
		obj2.display();
		
		
	}

}
