package StaticExamples;


class Bird4
{
	static  int x=5;
	
	static void message()
	{
		System.out.println("I am message method");
	}
	
	
	static class Nestedclass
	{
		static int y=20;
		
		
		 void display()
		{
			System.out.println(x);
			message();
			System.out.println(y);
		}
	}
	
	
} 
public class StaticClassExamples {

	public static void main(String[] args) {
		
		Bird4.Nestedclass obj=new Bird4.Nestedclass();
		obj.display();
		
		
		
	}

}
