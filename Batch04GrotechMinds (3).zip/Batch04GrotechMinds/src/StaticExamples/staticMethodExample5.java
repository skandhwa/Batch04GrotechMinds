package StaticExamples;

class Calculation
{
	static int rectangle(int length,int breadth)
	{
		return length*breadth;
	}
	
	static int square(int side)
	{
		return side*side;
	}
}

public class staticMethodExample5 {

	public static void main(String[] args) {
		
		
	System.out.println("The area of rectangle is  "+Calculation.rectangle(20,30));	
	
	System.out.println("the area of square is "+Calculation.square(20));
	
		

	}

}
