package InterfaceExamples;

interface Diagram
{
	void draw();
	void area();
	
}

class Rectangle implements Diagram
{
	public void draw()
	{
		System.out.println("I am drawing rectangle");
	}
	
	public void area()
	{
		System.out.println("I am creating area of rectangle");
	}
}

class Circle implements Diagram
{
	public void draw()
	{
		System.out.println("I am drawing Circle");
	}
	
	public void area()
	{
		System.out.println("I am creating area of circle");
	}
}

public class InterfaceExample2 {

	public static void main(String[] args) {
		
		//Diagram ref1=new Rectangle();
		Rectangle ref1=new Rectangle();
		
		ref1.draw();
		ref1.area();
		
		Diagram ref2=new Circle();
		ref2.draw();
		ref2.area();
		

	}

}
