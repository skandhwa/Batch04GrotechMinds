package InterfaceExamples;

interface Drawable4
{
	void draw();
	static int cube(int x)
	{
		return x*x*x;
	}
}
class Shape6 implements Drawable4
{
	public void draw()
	{
		System.out.println("I am draw method");
	}
}
public class InterfaceExample6 {

	public static void main(String[] args) {
		
		Drawable4 ref1=new Shape6();
		ref1.draw();
	System.out.println(Drawable4.cube(4));
		
	}

}
