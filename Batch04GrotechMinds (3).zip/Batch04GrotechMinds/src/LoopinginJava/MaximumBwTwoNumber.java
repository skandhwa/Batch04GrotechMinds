package LoopinginJava;

public class MaximumBwTwoNumber {

	public static void main(String[] args) {
		
		int a=20;
		int b=30;
		
		if(a>b)//20>30
		{
			System.out.println("a is maximum");
		}
		else
		{
			System.out.println("b is maximum");
		}
		
	}

}
