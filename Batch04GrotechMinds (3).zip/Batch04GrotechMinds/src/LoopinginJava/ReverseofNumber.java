package LoopinginJava;

public class ReverseofNumber {

	public static void main(String[] args) {

		int n=328;
		
		int x=n;
		int rev=0;
		
		while(x!=0)//123!=0///12!=0//1!=0//0!=0
		{
			int r=x%10;//r=123%10=3///r=12%10=2//r=1%10=1
			rev=rev*10+r;///rev=0*10+3=3///rev=3*10+2=32//rev=32*10+1=321
			x=x/10;///123/10///12/10=1//1/10=0
			
		}
		
		System.out.println("Reverse of number is " +rev);
		
		if(n==rev)
		{
			System.out.println("This number is palindrome");
		}
		else
		{
			System.out.println("Not palindrome");
		}
		
		
		

	}

}
