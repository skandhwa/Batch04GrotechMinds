package LoopinginJava;

public class PatternPrinting {

	public static void main(String[] args) {
		
		int row=5;
		
		for(int i=0;i<row;i++)//i=0,0<5//i=1,1<5
		{
			for(int j=0;j<=i;j++)//j=0,0<=1//j=1,1<=1//j=2,2<=1
			{
				System.out.print("* ");
			}
			
			System.out.println();
		}
		
		
		
		

	}

}
