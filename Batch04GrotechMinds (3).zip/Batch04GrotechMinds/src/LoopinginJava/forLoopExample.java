package LoopinginJava;

public class forLoopExample {

	public static void main(String[] args) {
		
		
		

	}

}
