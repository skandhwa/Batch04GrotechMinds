package LoopinginJava;

public class ifElseloopexample {

	public static void main(String[] args) {
		
		int number=18;
		
		if(number%2==0)
		{
			System.out.println("It is even number");
		}
		
		else
		{
			System.out.println("it is odd number ");
		}
		

	}

}
