package LoopinginJava;

public class WhileLoopExamples {

	public static void main(String[] args) {
		
		int x=5;///initialization
		
		while(x<10)//5<10//6<10//7<10//8<10//10<10//condition checking
		{
			System.out.println(x);//5//6//7//8//9
			x++;//5++//6++//7++//9++///increment/decrement 
		}
		
		
		

	}

}
