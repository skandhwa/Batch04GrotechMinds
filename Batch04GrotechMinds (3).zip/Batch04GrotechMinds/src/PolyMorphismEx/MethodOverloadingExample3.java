package PolyMorphismEx;

public class MethodOverloadingExample3 {
	
	static final float pi=3.14f;
	
	static int area(int x,int y)
	{
		return x*y;
	}
	
	static int area(int s)
	{
		return s*s;
	}
	
	static float area(float r,int h)
	{
		return  pi*r*r*h;
	}
	
	
		public static void main(String[] args) {
		
			MethodOverloadingExample3 obj=new MethodOverloadingExample3();
	System.out.println(obj.area(6));	
	System.out.println(		obj.area(4,5));
	System.out.println(		obj.area(5.6f,7));

	}

}
