package TakingUserInput;

import java.util.Scanner;

public class ScannerClassExample3 {

	public static void main(String[] args) {
		
		System.out.println("Enter Input as String");
		Scanner sc=new Scanner(System.in);
		String str=sc.nextLine();
		
	int x=	str.length();
	
	System.out.println("The length of String is  "+x);
		
		
		
		
		
	}

}
