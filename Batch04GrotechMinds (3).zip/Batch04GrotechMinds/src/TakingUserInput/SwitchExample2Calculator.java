package TakingUserInput;

import java.util.Scanner;

public class SwitchExample2Calculator {

	public static void main(String[] args) {
		
		double num1,num2;
		double result=0;
		char ch;
		while(true)
		{
		System.out.println("Enter the Operator of your choice");
		Scanner sc=new Scanner(System.in);
		ch=sc.next().charAt(0);
		
		
		
		
		
//		System.out.println(" +.Addition \n -.Subtraction \n *.Multiply \n /.Divion");
//		
//		System.out.println(" Please Enter your choice");
		
		System.out.println("Enter first numbers as input");
		num1=sc.nextDouble();
		System.out.println("Enter second number as input");
		num2=sc.nextDouble();
		
		switch(ch)
		{
		
		case '+':
		{
			result=num1+num2;
			System.out.println("The result is "+result);
			break;
			
		}
		
		case '-':
		{
			result=num1-num2;
			System.out.println("The result is "+result);
			break;
			
		}
		
		case '*':
		{
			result=num1*num2;
			System.out.println("The result is "+result);
			break;
			
		}
		
		
		case '/':
		{
			result=num1/num2;
			System.out.println("The result is "+result);
			break;
			
		}
		
		default:
		{
			System.out.println("Please enter valid input");
		}
		
		
		}
		
		
		
		
		}
		
		
		
		
		
		
		
		
		
		
		

	}

}
