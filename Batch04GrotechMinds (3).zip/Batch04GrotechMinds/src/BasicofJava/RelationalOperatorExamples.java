package BasicofJava;

public class RelationalOperatorExamples {

	public static void main(String[] args) {
		
		int a=10;
		int b=9;
		int c=20 ;
		int d=20;
		
		
		if(a>=b && b<=c && c==d && b!=a )
		{
			System.out.println("true");
		}
		else
			
			System.out.println("false");
		

	}

}
