package BasicofJava;

public class ShiftOperator {

	public static void main(String[] args) {
		
		int x=12;
		
		int y= 9 <<5;//// 9 * 2pow5 = 9*32
		
		System.out.println(y);
		
		int d=300;
		int e= d >> 3 ;/// 300 / 2pow3= 300/8=
		
		System.out.println(e);
		

	}

}
