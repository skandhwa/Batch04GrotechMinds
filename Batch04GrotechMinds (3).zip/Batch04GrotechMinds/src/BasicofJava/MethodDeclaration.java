package BasicofJava;

class A
{
	void display()
	{
		System.out.println("Hello");
		int x=10;
	double y=	Math.sqrt(125);
	}
}

public class MethodDeclaration {

	public static void main(String[] args) {
		
		A obj=new A();
		obj.display();
		
		

	}

}
