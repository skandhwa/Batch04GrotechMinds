//package BasicofJava;
//
//public class RoundOffFunction {
//
//	public static void main(String[] args) {
//		
////		float x=243.500f;
////	float y=	Math.round(x);
////	System.out.println(y);
////	
////	
////	double u=12312312.44554;
////	int h=(int)u;
////	
//	float g=9.88f;
////	
//	boolean ch=(boolean)g;
//	System.out.println(ch);
//		
//		
//
//	}
//
//}
