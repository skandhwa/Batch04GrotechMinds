package BasicofJava;

public class TypeCastingExample2 {

	public static void main(String[] args) {
		
		double d=165.88;
		
		int x=(int)d;
		
		System.out.println(x);
		

	}

}
