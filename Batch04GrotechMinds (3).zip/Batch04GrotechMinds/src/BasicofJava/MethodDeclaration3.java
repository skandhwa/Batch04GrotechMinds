package BasicofJava;

class B
{
	float display()
	{
		return 7.5f;
	}
	
	int message()
	{
		return 8;
	}
}

public class MethodDeclaration3 {

	public static void main(String[] args) 
	{
		
		B obj=new B();
	System.out.println(obj.display());	
	
	System.out.println(	obj.message());
		
		

	}

}
