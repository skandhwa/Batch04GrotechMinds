package AbstractionEx;


abstract class Bird10
{
	abstract void display();
	
	void message()
	{
		System.out.println("Hello I am concrete method");
	}
	
	void test()
	{
		System.out.println("I am test method");
	}
	
}


class Bird11 extends Bird10
{
	void display()
	{
		System.out.println("Hello");
	}
	
}


public class AbstractClassExample {

	public static void main(String[] args) {
		
		Bird11 obj=new Bird11();
		obj.display();
		obj.message();
		obj.test();
		
		
		 
		
		

		
	}

}
