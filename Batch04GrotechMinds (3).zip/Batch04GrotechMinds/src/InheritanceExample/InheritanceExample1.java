package InheritanceExample;

class Animal1///superclass
{
	void display()
	{
		System.out.println("I am display method");
	}
}

class Dog extends Animal1///Dog is called as subclass
{
	void test()
	{
		System.out.println("I am test method");
	}
}


public class InheritanceExample1 
{
	public static void main(String[] args) 
	{
		
		Dog obj=new Dog();
		obj.display();
		obj.test();
		
		

	}

}
