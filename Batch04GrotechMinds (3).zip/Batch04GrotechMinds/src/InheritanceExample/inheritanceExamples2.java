package InheritanceExample;

class Bird
{
	public String fly(String a,String b)
	{
		return a+b;
	}
}


class Vulture extends Bird
{
	
	public String eat(String c)
	{
		return c;
	}
}

public class inheritanceExamples2 {

	public static void main(String[] args) {
		
		Vulture obj=new Vulture();
	System.out.println(obj.fly("Parrot","Crow"));	
	System.out.println	(obj.eat("peacock"));
		

	}

}
