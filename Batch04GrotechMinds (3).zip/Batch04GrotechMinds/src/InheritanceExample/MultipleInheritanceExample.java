//package InheritanceExample;
//
//class Animal8
//{
//	void bark()
//	{
//		System.out.println("Animal barks");
//	}
//}
//
//
//class Cat
//{
//	void run()
//	{
//		System.out.println("All animal runs in class of cat");
//	}
//}
//
//class Leopard extends Cat,Animal
//{
//	void sleep()
//	{
//		System.out.println("Leopard sleep");
//	}
//}
//
//
//
//
//public class MultipleInheritanceExample {
//
//	public static void main(String[] args) {
//		
//
//	}
//
//}
