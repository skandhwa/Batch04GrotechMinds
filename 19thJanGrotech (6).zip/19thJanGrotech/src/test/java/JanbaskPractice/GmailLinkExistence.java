package JanbaskPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class GmailLinkExistence {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
		driver.manage().window().maximize();
		boolean flag=	driver.findElement(By.xpath("//a[text()='Gmail43242']")).isDisplayed();
		try
		{
	
		System.out.println(flag);
		
		if(flag==true)
		{
			System.out.println("Test Case passed");
		}
		
		
		
		}
		
		catch(Exception e)
		{
			System.out.println("Caught with "+e);
		}
		
		
		if(flag==false)
		{
			System.out.println("Test case failed");
		}
		
		
		
		
		

	}

}
