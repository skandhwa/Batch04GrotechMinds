package JanbaskPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebElementCommands1 {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://grotechminds.com/registration/");
	WebElement ele=	driver.findElement(By.xpath("//input[@id='fname']"));
	boolean flag=ele.isDisplayed();
	System.out.println(flag);
	
	if(flag==true)
	{
		ele.sendKeys("Saurabh");
	}
	
WebElement ele2=	driver.findElement(By.xpath("//input[@id='Male']"));

boolean flag2=ele2.isEnabled();
System.out.println(flag2);

if(flag2==true)
{
	ele2.click();
}
	
	
	
	
	
	
	

	}

}
