package JanbaskPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class IntercationBwBrowser {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
		
		
		WebDriver driver1=new FirefoxDriver();
		driver1.get("https://www.amazon.com");
		
		
		WebDriver driver2=new EdgeDriver();
		driver2.get("https://www.flipkart.com");
		
		Thread.sleep(4000);
		driver.close();
		Thread.sleep(4000);
		driver1.close();
		Thread.sleep(4000);
		driver2.close();
		
		

	}

}
