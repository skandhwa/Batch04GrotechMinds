package SeleniumBasics;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class WebDriverManagerExample {

	public static void main(String[] args) {
		
		WebDriver dr=new ChromeDriver();
		//System.setProperty("webdriver.chrome.driver","C:\\Users\\saura\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe");
        WebDriverManager.chromedriver().setup();
		
		
	}

}
