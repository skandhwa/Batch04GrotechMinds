package SeleniumBasics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebElementCommands3 {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://grotechminds.com/registration/");
		driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.xpath("//input[@id='fname']"));
	
	boolean flag=ele.isEnabled();
	
	System.out.println("Is the element enabled "+flag);
	
	if(flag==true)
	{
		ele.sendKeys("Saurabh");
	}
	
	
		
	}

}
