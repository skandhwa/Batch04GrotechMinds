package SeleniumBasics;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class UsingJAvaScriptexecutor2 {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new FirefoxDriver();
		driver.get("https://grotechminds.com/registration/");
		
		driver.manage().window().maximize();
		
		JavascriptExecutor js=(JavascriptExecutor) driver;
		js.executeScript("document.getElementById('fname').value='Saurabh';");
		
	WebElement ele=	driver.findElement(By.xpath("//input[@id='Male']"));
	
	
	js.executeScript("arguments[0].click();",ele);
	Thread.sleep(3000);
	
	js.executeScript("history.go(0)");
	Thread.sleep(3000);
	
	
	//js.executeScript("alert('Hello Saurabh');");
	
String text=	js.executeScript("return document.title;").toString();
System.out.println("The title of web page is "+text);
	
		

	}

}
