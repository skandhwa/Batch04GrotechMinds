package SeleniumBasics;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingWindowsinSeleniumEx {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Windows.html");
		driver.manage().window().maximize();
	String WindowId=	driver.getWindowHandle();
	System.out.println("The window id of main window is "+WindowId);
	driver.findElement(By.xpath("(//button[@class='btn btn-info'])[1]")).click();
	
	Set<String> WindowsIds=driver.getWindowHandles();
	System.out.println("The window id of all window is "+WindowsIds);
	
	Iterator<String> I1=WindowsIds.iterator();
	while(I1.hasNext())
	{
		String windowval=I1.next();
		if(!WindowId.equals(windowval))
		{
			driver.switchTo().window(windowval);
			String Title=driver.getTitle();
			System.out.println("The child window title is  "+Title);
			Thread.sleep(5000);
			driver.close();
		}
		
		
		
		
	}
	
	
	driver.switchTo().window(WindowId);
	
	String TitlePrevious=driver.getTitle();
	System.out.println("The main window title is "+TitlePrevious);
	
	
	
	
		
		

	}

}
