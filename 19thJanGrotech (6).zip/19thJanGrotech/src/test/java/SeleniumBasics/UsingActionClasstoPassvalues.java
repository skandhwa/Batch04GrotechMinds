package SeleniumBasics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class UsingActionClasstoPassvalues {

	public static void main(String[] args) {
		
WebDriver driver=new ChromeDriver();
		
		
		
		driver.get("https://grotechminds.com/registration/");
		driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.id("fname"));
	Actions act=new Actions(driver);
	
	act.sendKeys(ele,"Saurabh").build().perform();

	}

}
