package Constants;

public class constants {
	
	
	public static final String TESTDATAPATH="src\\main\\java\\TestData\\TestData28Feb2024.xlsx";
	public static final String PROPERTYFILEPATH="src\\main\\java\\Constants\\GlobalData.properties";
	public static final String SCREENSHOTPATH="target\\ScreenShots\\"+Math.random()+"test.jpeg";
	

}
