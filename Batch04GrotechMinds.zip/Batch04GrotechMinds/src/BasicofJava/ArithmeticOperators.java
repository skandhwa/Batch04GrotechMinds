package BasicofJava;

public class ArithmeticOperators {

	public static void main(String[] args) {
		
		int x=21;
		int y= 4;
		
		int z= x/y;
		int f= x%y;
		
		System.out.println(z);
		System.out.println(f);
		
		

	}

}
