package BasicofJava;

public class DataTypes {

	public static void main(String[] args) {
		
		//boolean flag=true;
		
		int x=45;
		
		//byte h=-321;//-128 to +127 //1 byte
		
		//short t=651221;///-32768 to +32767//-2pw 16 to + 2pw16-1
		
		//16 bit 
		
		int y=-213413233;///-2,147,483,648 to 2,147,483,647
		
		
		long t=2131232432749328L;
		
		float u=12312312454354533453453454312312.2342313345345345453453453454123122f;
		
		double k=12312312312312.1231231231231232;
		
		char n='AB';

	}

}
