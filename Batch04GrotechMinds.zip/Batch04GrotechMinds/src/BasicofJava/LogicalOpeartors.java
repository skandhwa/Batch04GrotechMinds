package BasicofJava;

public class LogicalOpeartors {

	public static void main(String[] args) {
		
		int a=20;
		int b=10;
		int c=30; 
		
//		if(a>b && b<c && c>a && c<b)//20>10 && 10<30 && 30>20 && 30<10
//		{
//			System.out.println("I am true");
//		}
//		
//		else
//			System.out.println("I am false");
		
		if(a<b || c<b || a>c || c>b)//10<20 || 30<10 ||20>30 ||30>10
		{
			System.out.println("I am true");
		}
		else
		{
			System.out.println("I am false");
		}
		
		
		
		if(!(a<b))
		{
			System.out.println("my value is true");
		}
		else
		{
			System.out.println("my value is false");
		}
		
		
		

	}

}
