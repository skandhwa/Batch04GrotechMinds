package InheritanceExample;

class Animal7
{
	void eat()
	{
		System.out.println("Animal is eating");
	}
}

class Fox extends Animal7
{
	void drink()
	{
		System.out.println("Fox Drinks water");
	}
}

class wolf extends Animal7
{
	void eat()
	{
		System.out.println("Wolf is sleeping");
	}
	
	void culture()
	{
		eat();
		super.eat();
	}
}

public class HierarchicalinheritanceEx {

	public static void main(String[] args) {
		
		Fox obj=new Fox();
		obj.drink();
		obj.eat();
		wolf obj1=new wolf();
		obj1.culture();
		

	}

}
