package InheritanceExample;

class Animal4
{
	Animal4()
	{
		System.out.println("Animal is created");
	}
}

class Tiger extends Animal4
{
	Tiger()
		{
		super();
		System.out.println("Tiger created");
		
	}
}
public class SuperExample3 {

	public static void main(String[] args) {
		
		Tiger obj=new Tiger();
		
		
		

	}

}
