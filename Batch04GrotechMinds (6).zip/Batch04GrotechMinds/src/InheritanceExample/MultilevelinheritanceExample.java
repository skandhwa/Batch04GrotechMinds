package InheritanceExample;

class childPlay
{
	void display2()
	{
		System.out.println("i am top level class");
	}
}



class Toy extends childPlay
{
	void test()
	{
		System.out.println("I am testing a toy");
	}
}

class Puzzle extends Toy
{
	void message()
	{
		System.out.println("i am jigsaw puzzle");
	}
}


class Motoroctane extends Puzzle
{
	void display()
	{
		System.out.println("i am manufacturer of toy motor cars");
	}
}

public class MultilevelinheritanceExample {

	public static void main(String[] args) {
		
		Motoroctane obj=new Motoroctane();
		obj.test();
		obj.display();
		obj.message();
		obj.display2();
		
		

	}

}
