package StringPrograms;

public class StringReverse {

	public static void main(String[] args) {
		
		String str="Saurabh";
		
		String revstr="";
		
		for(int i=str.length()-1;i>=0;i--)//i=6,6>=0//i=5,5>=0//i=4,4>=0
		{
			
			revstr=revstr+str.charAt(i);//revstr=h//revstr=h+b=hb//revstr=hb+
			
		}
		
		
		System.out.println(revstr);
		

	}

}
