package StringPrograms;

public class SwapString {

	public static void main(String[] args) {
		
		String s1="abc";
		
		String s2="def";
		
		s1=s1+s2;
		
		s2=s1.substring(0,s1.length()-s2.length());
		///s2=s1.substring(0,6-3)
		
		///s2=s1.substring(0,3)
		
		s1=s1.substring(s2.length());
		
		System.out.println(s1);
		System.out.println(s2);

	}

}
