package PolyMorphismEx;


class Test5
{
	int add(int a,int b)
	{
		return a+b;
	}
	
	float add(float c,float d)
	{
		return c+d;
	}
}

public class MethodOverloadingExample2 {

	public static void main(String[] args) {
		
		Test5 obj=new Test5();
	System.out.println(obj.add(45.6f,67.8f));	
		
	System.out.println(	obj.add(12,24));
		
		

	}

}
