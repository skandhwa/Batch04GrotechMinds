package PolyMorphismEx;

class Bike11
{
	int run(int a)
	{
		System.out.println("I am running");
		return a;
	}
	
	float run(float a)
	{
		System.out.println("I am also running");
		return a;
	}
	
}






public class MethodOverloadingExample {

	public static void main(String[] args) {
	

	}

}
