package PolyMorphismEx;


	
	class Test7
	{
		int area(int x,int y)
		{
			return x*y;
					
		}
	}
	
	class Test6 extends Test7
	{
		int area(int x,int y)
		{
			return x*y;
		}
	}
	
	class Test8 extends Test7
	{
		int area(int x,int y)
		{
			return x*y;
		}
	}
	
	
	
	public class MethodOverridingExample1 {

	public static void main(String[] args) {
		
		Test6 obj=new Test6();
	System.out.println(obj.area(3, 4));	
		
		
		
		

	}

}
