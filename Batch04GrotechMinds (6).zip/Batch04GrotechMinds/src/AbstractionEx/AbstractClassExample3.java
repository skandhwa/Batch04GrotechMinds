package AbstractionEx;

abstract class Bank
{
	int x=10;
	
	abstract int getROI(int x);
	void display()
	{
		System.out.println("Hello");
	}
	abstract void test();
	
}

class SBI extends Bank
{
	int getROI(int y)
	{
		return y;
	}
	
	void test()
	{
		System.out.println("i am test method");
	}
}


class BOB extends Bank
{
	int getROI(int z)
	{
		return z;
	}
	
	void test()
	{
		System.out.println("i am BOB test method");
	}
}

class AXIS extends Bank
{
	int getROI(int c)
	{
		return c;
	}
	
	void test()
	{
		System.out.println("i am Axis test method");
	}
	
}





public class AbstractClassExample3 {

	public static void main(String[] args) {
		
		Bank ref=new SBI();
	System.out.println(ref.getROI(6));	
	
	ref.test();
		
		Bank ref1=new AXIS();
		System.out.println(	ref1.getROI(8));
		ref1.test();
		
		Bank ref2=new BOB();
		System.out.println(	ref2.getROI(9));
		ref2.test();
		
		
		

	}

}
