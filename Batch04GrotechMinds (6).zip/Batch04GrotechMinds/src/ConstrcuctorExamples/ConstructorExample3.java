package ConstrcuctorExamples;

class Student4
{
	int id;
	String name;
	
	Student4(int i,String n)
	{
		id=i;
		name=n;
		
	}
	
	void display()
	{
		System.out.println(id+ " "+name);
	}
	
	
}
public class ConstructorExample3 {

	public static void main(String[] args) {
		
		Student4 obj=new Student4(235,"Saurabh");
		Student4 obj1=new Student4(135,"Gaurabh");
		Student4 obj2=new Student4(335,"Ravi");
		obj.display();
		obj1.display();
		obj2.display();
		
		
		

	}

}
