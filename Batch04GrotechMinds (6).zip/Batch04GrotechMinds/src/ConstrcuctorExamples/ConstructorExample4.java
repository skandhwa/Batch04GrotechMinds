package ConstrcuctorExamples;

class Student5
{
	int id;
	String name;
	int age;
	
	Student5(int i,String n)
	{
		id=i;
		name=n;
	}
	
	Student5(String n,int i)
	{
		id=i;
		name=n;
	}
	
	Student5(int i,String n,int a)
	{
		id=i;
		name=n;
		age=a;
		
	}
	
	Student5(String n1)
	{
		name=n1;
		
	}
	
	void display()
	{
		System.out.println(id+ " "+name+" "+age);
	}
	
	
	
}
public class ConstructorExample4 {

	public static void main(String[] args) {
		Student5 obj=new Student5(23,"Saurabh");
		obj.display();
		Student5 obj1=new Student5(23,"Saurabh",35);
		obj1.display();
		Student5 obj2=new Student5("Rohit");
		obj2.display();
		Student5 obj3=new Student5("Rohit",89);
		obj3.display();

	}

}
