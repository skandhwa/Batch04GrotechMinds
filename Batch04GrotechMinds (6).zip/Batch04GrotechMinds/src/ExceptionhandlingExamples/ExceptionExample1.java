package ExceptionhandlingExamples;

import java.lang.*;

public class ExceptionExample1 {

	public static void main(String[] args) {
		
//		try
//		{
//		
//		int x=10;
//		
//		int y=x/0;
//		
//		System.out.println(y);///Arithmetic Exception
//		
//		}
//		
//		catch(ArithmeticException e)
//		{
//			System.out.println("caught with  "+e);
//		}
		
		
		
		
		
		try
		{
		
		int []a= {12,45,56,78,99};
		
		System.out.println(a[6]);///Array Index out of bounds exception 
		
		}
		
		catch(Exception e)
		{
			
			System.out.println("caught with " +e);
		}
		
		
		
		
//		try
//		{
//		
//		String str=null;
//		int x=str.length();
//		System.out.println(x);////Null pointer exception 
//		
//		}
//		
//		catch(NullPointerException e)
//		{
//			System.out.println("caught with "+e);
//		}
//		
		
		
		
		
		
    int m=10;
	int n=m+20;
	System.out.println("The sum of m and n is  "+n);
		
		
		

	}

}
