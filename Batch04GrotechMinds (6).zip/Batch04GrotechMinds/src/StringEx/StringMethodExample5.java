package StringEx;

public class StringMethodExample5 {

	public static void main(String[] args) {
		
		String str="  hello Java    ";
		System.out.println(str);
		String str2=str.trim();
		System.out.println(str2);
		

	}

}
