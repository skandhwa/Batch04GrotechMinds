package StringEx;

public class StringMethodsExample3 {

	public static void main(String[] args) {
		
		String str="India";
	 str=	str.concat("Republic");
		System.out.println(str);
		
		

	}

}
