package StringEx;

public class StringExample4 {

	public static void main(String[] args) {
		
		String str="Brazil is country in south america";
	String str1=	str.replace("South", "north");
		System.out.println(str1);
		
		
		String str2="    Saurabh Kandhway   ";
		
		System.out.println(str2);
		
		String str3=str2.replace(" ", "");
		
		System.out.println("After replacing value is");
		
		System.out.println(str3);
		
		
		

	}

}
