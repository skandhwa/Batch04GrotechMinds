package StringEx;

public class StringExample2 {

	public static void main(String[] args) {
		
		String str1="Java";///Through String Literal
		
		
		char []ch= {'P','y','t','h','o','n'};
		String str2=new String(ch);///Converting char array to string
		
		
		String str3=new String("India");
		
		
		System.out.println(str1);
		System.out.println(str2);
		System.out.println(str3);
		
		
		

	}

}
