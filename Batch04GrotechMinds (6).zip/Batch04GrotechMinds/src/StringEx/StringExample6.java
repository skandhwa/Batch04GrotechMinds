package StringEx;

public class StringExample6 {

	public static void main(String[] args) {
		
		String str1="Java@is Programming @language";
		
	String[]words=	str1.split("@");
	
	for(String s:words)
	{
		System.out.println(s);
	}
	
		
		
		
		

	}

}
