package StringEx;

public class StringMethodExample4 {

	public static void main(String[] args) {
		
		String str1="australia@  ant% matchbox# ";
		
	String str2=	str1.replace("a","b");
		
	System.out.println(str2);
	

	}

}
