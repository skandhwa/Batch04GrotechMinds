package StringEx;

public class StringExample1 {

	public static void main(String[] args) {
		
		
		int []a= {2,4,5,6,7,8};
		
		char []ch= {'I','N','D','I','A'};
		
		String str=new String(ch);
		
		///By Using StringLiteral
		
		String s1="India";
		
		String s2="India";
		
		///By Using New Keyword
		
		String str1=new String("Saurabh");
		
		

	}

}
