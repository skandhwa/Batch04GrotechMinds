package StringEx;

public class StringLowerandUpperCase {

	public static void main(String[] args) {
		
		
		String str1="india is an independent country";
		
	str1=	str1.toUpperCase();
		
		System.out.println(str1);
		
		
	str1=	str1.toLowerCase();
		
	System.out.println(str1);
		

	}

}
