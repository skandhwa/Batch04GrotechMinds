package StringEx;

public class StringExample3 {

	public static void main(String[] args) {
		
		String str=" ";
		
	boolean flag=	str.isEmpty();
	
	System.out.println(flag);
		

	}

}
