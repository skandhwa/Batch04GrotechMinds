package StringEx;

public class StringImmutableexample {

	public static void main(String[] args) {
		
		String str="Saurabh";
		
	String str1=	str.concat("Kandhway");
		
		
		System.out.println(str1);
		
		
		
		

	}

}
