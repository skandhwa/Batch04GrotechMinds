package StringEx;

public class StringExample7 {

	public static void main(String[] args) {
		
		String str="Java is an object oriented PL";
		
	int x=	str.indexOf("an");
	
	
	System.out.println(x);
	
	
	
	
	
	
	
	
	
	
		
		
	}

}
