package StringEx;

public class StringMethodsExample2 {

	public static void main(String[] args) {
		
		String str1="India";
		String str2="INDIA";
		
		boolean flag=str1.equalsIgnoreCase(str2);
		
		System.out.println(flag);
		

	}

}
