package StringEx;

public class StringMethodsexample1 {

	public static void main(String[] args) {
		
		String str="Saurabh";
	char ch=	str.charAt(5);
	System.out.println(ch);
	
	int x=str.length();
	System.out.println(x);
	
	
	String str1="Mahantesh";
	String str2=str1.substring(3,7);
	System.out.println(str2);
	
		
		

	}

}
