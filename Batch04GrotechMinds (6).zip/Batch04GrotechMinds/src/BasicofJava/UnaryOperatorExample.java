package BasicofJava;

public class UnaryOperatorExample {

	public static void main(String[] args) {
		
		
//		int x=20;
//		
//		int y= x--;//y=20
//		
//		System.out.println(y);
		
		
		
		
//		int c= ++a + b-- + --b ;
//		
//		
//		int d= a++  + --b + ++a;
//		
		/// 20 + 29 + (++21)
		
		//20+29+22
		
		// 21 + 30 +  (--29)
		//21+30 +28
		
//		int a=10;
//		int b=20;
//		int c=30;
		
		
//		int f= a++ + b++ + --c  + a++ + ++b - --a;
//		System.out.println(f);
		
		////  10 + 20 + 29 + 11 + 22 - 11
		
		
//		System.out.println(c);
//	//	System.out.println(d);
		
		
		
		int a=5;
		int b=6;
		int c=7;
		
		int f= a++ + c++  - --a + b++ - --b + ++c ;
		 
		
		////  5 + 7 - (--6) + 6 - (--7)  + (++8)
		
		///  5+7 -5 +6 - 6 +9
		
		System.out.println(f);
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
