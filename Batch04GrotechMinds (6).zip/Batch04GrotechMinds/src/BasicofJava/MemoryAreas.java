package BasicofJava;

class E
{
	public void display()
	{
		System.out.println("Hello");
		int y=20;
	}
	
	public void message()
	{
		int p=20;
		int q=30;
		int r=p+q;
		System.out.println(r);
	}
	
	public void getSqaureroot()
	{
		double h=Math.sqrt(225);
		System.out.println(h);
	}
}



public class MemoryAreas {

	public static void main(String[] args) {
		
		E obj=new E();
		obj.display();
		obj.message();
		obj.getSqaureroot();
		

	}

}
