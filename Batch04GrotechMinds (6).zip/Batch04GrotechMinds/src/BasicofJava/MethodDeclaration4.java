package BasicofJava;

class C
{
	void display(int a,int b,int f)
	{
		int c=a+b+f;
		System.out.println(c);
	}
	
	void message(int y,int z)
	{
		float k=y+z;
		System.out.println(k);
	}
}


public class MethodDeclaration4 {

	public static void main(String[] args) {
		
		C obj=new C();
		obj.display(12,20,65);
		obj.message(56, 78);
		

	}

}
