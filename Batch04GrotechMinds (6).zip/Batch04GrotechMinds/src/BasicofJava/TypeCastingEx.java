package BasicofJava;

public class TypeCastingEx {

	public static void main(String[] args) {
		
		int x=10;
		long y=x;
		///automatically converting integer to long data type
		
		float z=y;
		
		///automatically converting long to float data type

	}

}
