package InterfaceExamples;

interface Bank
{
	float rateofIntrest();
}

class SBI implements Bank
{
	public float rateofIntrest()
	{
		return 9.5f;
	}
}

class BOB implements Bank
{
	public float rateofIntrest()
	{
		return 8.5f;
	}
	
}
public class InterfaceExample3 {

	public static void main(String[] args) {
		
		Bank ref1=new SBI();
	System.out.println(ref1.rateofIntrest());	
	
	Bank ref2=new BOB();
	System.out.println (	ref2.rateofIntrest());
	
		
		
		

	}

}
