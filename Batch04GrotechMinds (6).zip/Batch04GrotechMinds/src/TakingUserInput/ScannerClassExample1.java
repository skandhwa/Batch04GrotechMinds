package TakingUserInput;

import java.util.Scanner;

import java.math.*;

public class ScannerClassExample1 {

	public static void main(String[] args) {
		
//		int x=20;
//		int y=30;
//		int z=x+y;
//		System.out.println(z);
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the First Number");
		
		int x=sc.nextInt();
		
		System.out.println("Enter the Second Number");
		
		int y=sc.nextInt();
		
		int z=x+y;
		
		System.out.println("The sum of x and y is  "+z);
		
		
		

	}

}
