package LoopinginJava;

public class forloopExamples {

	public static void main(String[] args) {

		
		for(int i=0;i<5;i++)////i=0,0<5//i=1,1<5//i=2,2<5//i=3,3<5//i=4,4<5//i=5,5<5
		{
			System.out.println(i);//0//1//2//3//4
			//
			
			
			///
			//i++//0++
		}
		

	}

}
