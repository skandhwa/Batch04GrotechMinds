package LoopinginJava;

public class WhileLoopInfinite {

	public static void main(String[] args) {
		
		
		while(true)
		{
			System.out.println("I will run infinte times");
		}

	}

}
