package LoopinginJava;

public class ProgramDoWhileLoop {

	public static void main(String[] args) {
		
		int x=15;
		int sum=0;
		
		do
		{
			sum+=x;
			x--;
			
		}
		
		while(x>10);
		System.out.println(sum);
		
		

	}

}
