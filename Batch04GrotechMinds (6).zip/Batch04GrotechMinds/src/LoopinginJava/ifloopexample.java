package LoopinginJava;

public class ifloopexample {

	public static void main(String[] args) {
		
//		int x=10;
//		if(x>11)
//		{
//			System.out.println("true");
//		}
//		

            int age=25;
            if(age>18)
            {
            	System.out.println("you are elligible to vote ");
            }

	}

}
