package ThisExample;

class Student8
{
	int id;
	String name;
	String college;
	float fee;
	
	Student8(int id,String name,String college)
	{
		this.id=id;
		this.name=name;
		this.college=college;
		
	}
	
	Student8(int id,String name,String college,float fee)
	{
		this(id,name,college);
		this.fee=fee;
	}
	
	
	
	void display()
	{
		System.out.println(id+" "+name+" "+college+" "+fee);
	}
	
	
	
}
public class thisExample3 {

	public static void main(String[] args) {
		
		Student8 obj=new Student8(200,"Harish","IIM");
        obj.display();
        Student8 obj1=new Student8(300,"Girish","IIT",5000.50f);
        obj1.display();
		
	}

}
