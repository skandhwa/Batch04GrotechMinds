package ThisExample;

class Animal7
{
	void m()
	{
		System.out.println("I am m method");
	}
	void n()
	{
		System.out.println("i am n method");
		this.m();
	}
	
}


public class thisExample2 {

	public static void main(String[] args) {
		
		Animal7 obj=new Animal7();
		obj.n();
		
		

	}

}
