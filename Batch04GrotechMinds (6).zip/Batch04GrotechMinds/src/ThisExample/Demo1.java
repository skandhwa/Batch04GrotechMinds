package ThisExample;

public class Demo1 {
	
	Demo1()
	{
		System.out.println("i am default constructor");
	}
	
	int x=10;
	
	static
	{
		System.out.println("This is static block");
	}
	
	
	static void display()
	{
		System.out.println("Hello ");
	}
	

	public static void main(String[] args) {
		
		Demo1.display();
		
		
		
	}

}
