package AccessModifierExample2;




public class ProtectedExample3 extends   {

	public static void main(String[] args) {
		
		Test6 obj=new Test6();
		obj.
		
		
		
		

	}

}
