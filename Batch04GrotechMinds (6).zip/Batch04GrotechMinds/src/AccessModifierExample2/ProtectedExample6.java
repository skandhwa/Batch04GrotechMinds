package AccessModifierExample2;

import AccessModifierExamples.ProtectedExample4;

public class ProtectedExample6 extends ProtectedExample4 {

	public static void main(String[] args) {
		
		ProtectedExample6 obj=new ProtectedExample6();
		obj.display();
		
		
		

	}

}
