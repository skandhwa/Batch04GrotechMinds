package AccessModifierExamples;

public class PublicExample1 {
	
	private void display()
	{
		System.out.println("Hello I am public method");
		int x=9/0;
		System.out.println(x);
		
	}
	
	

	public static void main(String[] args) {
		
		PublicExample1 obj=new PublicExample1();
		obj.display();
		
		
	}

}
