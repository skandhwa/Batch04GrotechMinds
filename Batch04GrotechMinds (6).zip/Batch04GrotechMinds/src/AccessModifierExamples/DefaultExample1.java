package AccessModifierExamples;

class Test5
{
	void display()
	{
		System.out.println("Hello This is Java");
	}
}

public class DefaultExample1 {

	public static void main(String[] args) {
		
		Test5 obj=new Test5();
		obj.display();
		

	}

}
