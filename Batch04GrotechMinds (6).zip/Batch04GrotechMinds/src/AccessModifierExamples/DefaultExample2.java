package AccessModifierExamples;

public class DefaultExample2 {

	public static void main(String[] args) {
		
		Test5 obj=new Test5();
		obj.display();
		
		

	}

}
