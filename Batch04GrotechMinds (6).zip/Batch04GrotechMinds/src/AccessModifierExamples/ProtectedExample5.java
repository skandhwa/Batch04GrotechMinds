package AccessModifierExamples;

public class ProtectedExample5 {

	public static void main(String[] args) {
		
		ProtectedExample4 obj=new ProtectedExample4();
		obj.display();
		

	}

}
