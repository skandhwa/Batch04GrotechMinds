package ArrayExamples;

public class LargestSmallestNumberArray {
	
	public static int getLargest(int []a,int length)
	{
		for(int i=0;i<length;i++)
		{
			for(int j=i+1;j<length;j++)
			{
				
				if(a[i]>a[j])
				{
					
					int t=a[i];
					a[i]=a[j];
					a[j]=t;
					
				}
				
			}
		}
		
		return a[2];
		
		
		
		
	}
	
	public static void main(String[] args) {
		
		
		int []a= {6,12,4,18,1,7,34,121,3,2,567,89};
		
	System.out.println(getLargest(a,12));	
		
		

	}

}
