package ArrayExamples;

import java.util.Arrays;

public class ArrayExamples4 {

	public static void main(String[] args) {
		
		
		int []a= {2,14,15,45};
		int []b= {2,54,15,45};
		
	boolean flag=	Arrays.equals(a,b);
	
	System.out.println(flag);
		
		
		
		

	}

}
