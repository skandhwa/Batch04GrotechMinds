package ArrayExamples;

public class ArrayExample2 {

	public static void main(String[] args) {
		
		int a[]= {20,30,40,50,60,70,80,90};
		
	int x=	a.length;
	System.out.println("The length of array is  "+x);
		
		
		for(int i:a)
		{
			System.out.println(i);
		}
		
		

	}

}
