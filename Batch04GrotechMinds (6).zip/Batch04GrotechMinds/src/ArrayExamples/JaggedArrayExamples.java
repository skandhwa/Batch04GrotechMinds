package ArrayExamples;

public class JaggedArrayExamples {

	public static void main(String[] args) {
		
		int [][] a=
				
			{
					{1,2,3},
					{4,5},
					{6,7,8,10},
					{5,9,12,45,67}
					
			};
		
		
		int x=a.length;
		System.out.println(x);
		
		System.out.println();
		
		System.out.println("The elements of array are ::");
		
		for(int i=0;i<x;i++)//i=2,1<4
		{
			for(int j=0;j<a[i].length;j++)
			{
				System.out.print("  " +a[i][j]);
			}
			
			System.out.println();
		}
		
		
		
		

	}

}
