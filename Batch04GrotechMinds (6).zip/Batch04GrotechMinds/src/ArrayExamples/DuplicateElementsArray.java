package ArrayExamples;

public class DuplicateElementsArray {

	public static void main(String[] args) {
		
		
		int []a=new int[] {1,4,2,6,4,7,1};
		
		for(int i=0;i<a.length;i++)//i=0,0<7
		
		{
			for(int j=i+1;j<a.length;j++)//j=1,1<7,j=2,2<7
			{
				if(a[i]==a[j])///
				{
					System.out.println(a[j]);
				}
			}
		}
		
		
		

	}

}
