package ArrayExamples;

public class SortingAnArrayExamples {

	public static void main(String[] args) {
		
		
		int []a= {12,3,1,56,9};
		
		for(int i=0;i<a.length;i++)///i=2,2<5
		{
			for(int j=i+1;j<a.length;j++)///j=4,4<5
			{
				if(a[i]>a[j])//a[2]>a[4]
				{
					int t=a[i];
					a[i]=a[j];
					a[j]=t;
					
					
					
				
				}
				
				
			}
			
			
			System.out.println(a[i]);
			
		}
		
		
		

	}

}
