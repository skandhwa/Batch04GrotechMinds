package ArrayExamples;

public class ArrayIndexOutOfBounds {

	public static void main(String[] args) {
		
//		int []a= {12,34,56,78,89,91};
//		
//		System.out.println(a[7]);
		
		
		int []b=new int[5];
		
		b[0]=10;
		b[1]=20;
		b[2]=30;
		b[3]=40;
		b[4]=50;
		b[5]=60;
		
		for(int i=0;i<b.length;i++)
		{
			System.out.println(b[i]);
		}
		
		
		
		

	}

}
