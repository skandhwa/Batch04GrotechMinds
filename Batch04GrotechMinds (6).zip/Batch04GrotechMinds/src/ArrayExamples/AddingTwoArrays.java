package ArrayExamples;

public class AddingTwoArrays {

	public static void main(String[] args) {
		

		System.out.println("My first Array is ------------>");
		
		
		
		int [][]a= {{1,3,4},{5,7,9},{2,6,8}};
		
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
			{
				System.out.print(" " +a[i][j]);
			}
			
			System.out.println();
		}
		
		System.out.println();
		
System.out.println("My Second Array is ------------>");
		
		
		
		int [][]b= {{1,5,8},{6,2,10},{3,4,11}};
		
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
			{
				System.out.print(" " +a[i][j]);
			}
			
			System.out.println();
		}
		
		System.out.println();
		
		
		System.out.println("The Result Array is ");
		
		int [][]c=new int [3][3];
		
		
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
		
			{
		c[i][j]=a[i][j]+b[i][j];
		
		
		System.out.print(" "+c[i][j]);
			}
			
			System.out.println();
			
		}
		
		
		
		

	}

}
