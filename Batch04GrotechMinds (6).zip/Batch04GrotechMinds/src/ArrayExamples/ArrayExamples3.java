package ArrayExamples;

import java.util.Arrays;

public class ArrayExamples3 {

	public static void main(String[] args) {
		
		int []a= {2,14,15,45};
		int []b= {14,5,22,14,15};
		
		
		
	Arrays.sort(b);
	
	for(int i:b)
	{
		System.out.println(i);
	}
	
	
		
		
	int x=	Arrays.compare(b,a);
	
	
	System.out.println("The result of comparision is  "+x);
		

	}

}
